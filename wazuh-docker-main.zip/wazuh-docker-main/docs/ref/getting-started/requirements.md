# Reference Manual - Requirements

Before deploying Wazuh-Docker (version 5.1.0), it's essential to ensure your environment meets the necessary hardware and software requirements. Meeting these prerequisites will help ensure a stable and performant Wazuh deployment.

## Host System Requirements

These are general recommendations. Actual needs may vary based on the number of agents, data volume, and usage patterns.

### Hardware:

* **CPU**:
    * **Minimum**: 2 CPU cores.
    * **Recommended**: 4 CPU cores or more, especially for production environments or deployments with a significant number of agents.
* **RAM**:
    * **Minimum (Single-Node Test/Small Environment)**: 4 GB RAM. This is a tight minimum; 6 GB is safer.
        * Wazuh Indexer (OpenSearch): Typically requires at least 1 GB RAM allocated to its JVM heap.
        * Wazuh Manager: Resource usage depends on the number of agents.
        * Wazuh Dashboard (OpenSearch Dashboards): Also consumes memory.
    * **Recommended (Production/Multiple Agents)**: 8 GB RAM or more.
* **Disk Space**:
    * **Minimum**: 50 GB of free disk space.
    * **Recommended**: 100 GB or more, particularly for the Wazuh Indexer data. Disk space requirements will grow over time as more data is collected and indexed.
    * **Disk Type**: SSDs (Solid State Drives) are highly recommended for the Wazuh Indexer data volumes for optimal performance.
* **Network**:
    * A stable network connection with sufficient bandwidth, especially if agents are reporting from remote locations.

### Software Prerequisites:

#### Linux:

* **Docker Engine**:
    * Version `20.10.0` or newer.
    * Install Docker by following the official instructions: [Install Docker Engine](https://docs.docker.com/engine/install/).
* **Git Client**:
    * Required for cloning the `wazuh-docker` repository.
* **Web Browser**:
    * A modern web browser (e.g., Chrome, Firefox, Edge, Safari) for accessing the Wazuh dashboard.
* **`vm.max_map_count` (Linux Hosts for Wazuh Indexer/OpenSearch)**:
    * The Wazuh Indexer (OpenSearch) requires a higher `vm.max_map_count` setting than the default on most Linux systems.
    * Set it permanently:
        1.  Edit `/etc/sysctl.conf` and add/modify the line:
            ```
            vm.max_map_count=262144
            ```
        2.  Apply the change without rebooting:
            ```bash
            sudo sysctl -p
            ```
    * This is crucial for the stability of the Wazuh Indexer.

#### Windows:

* **Docker Desktop**
    * Install Docker Desktop by following the official instructions: [Install Docker Desktop](https://docs.docker.com/desktop/setup/install/windows-install/).
* **WSL Linux distribution**
<<<<<<< HEAD
    * Install Ubuntu or other compatible Linux distribution (bash in Alpine is not compatible with wazuh-certs-tool-5.1.0-1.sh): [Install Ubuntu on WSL](https://documentation.ubuntu.com/wsl/stable/howto/install-ubuntu-wsl2/)
=======
    * Install Ubuntu or other compatible Linux distribution (bash in Alpine is not compatible with wazuh-certs-tool.sh): [Install Ubuntu on WSL](https://documentation.ubuntu.com/wsl/stable/howto/install-ubuntu-wsl2/)
>>>>>>> 3844cd03aeec869827540292730c4d4eea1e702c
* **Git Client**:
    * Required for cloning the `wazuh-docker` repository.
* **Web Browser**:
    * A modern web browser (e.g., Chrome, Firefox, Edge, Safari) for accessing the Wazuh dashboard.

#### macOS:

* **Docker Desktop**
    * Install Docker Desktop by following the official instructions: [Install Docker Desktop](https://docs.docker.com/desktop/setup/install/mac-install/).
* **Bash Shell**
* **GNU versions of apps**:
    * [Install GNU sed](https://formulae.brew.sh/formula/gnu-sed).
    * [Install GNU awk](https://formulae.brew.sh/formula/gawk).
    * [Install GNU grep](https://formulae.brew.sh/formula/grep).
* **OpenSSL**:
    * [Install OpenSSL](https://formulae.brew.sh/formula/openssl@3).
* **Git Client**:
    * Required for cloning the `wazuh-docker` repository.
* **Web Browser**:
    * A modern web browser (e.g., Chrome, Firefox, Edge, Safari) for accessing the Wazuh dashboard.

## Network Ports

Ensure that the necessary network ports are open and available on the Docker host and any firewalls:

* **Wazuh Manager**:
    * `1517/TCP`: For agent communication and enrollment. Wazuh 5.x agents use a
      single HTTPS channel for both, so this is the only port they need.
    * `1514/TCP`: For agent communication with Wazuh 4.x agents (legacy
      `remoted`). Kept for backward compatibility, not used by 5.x agents.
    * `1515/TCP`: For agent enrollment with Wazuh 4.x agents (`wazuh-authd`).
      Kept for backward compatibility, not used by 5.x agents.
    * `55000/TCP`: For Wazuh API (default).
    * `1516/TCP`: For cluster communication between manager nodes. Only needed
      between the manager containers, not on the Docker host.
* **Wazuh Indexer**:
    * `9200/TCP`: For HTTP REST API. **Not published on the host.** The manager
      and the dashboard reach it over the Compose network, and the account that
      answers on it administers the datastore. If you need it for development,
      add the mapping bound to the loopback address (`127.0.0.1:9200:9200`).
    * `9300/TCP`: For inter-node communication (if clustered). Only needed
      between the indexer containers, not on the Docker host.
* **Wazuh Dashboard**:
    * `443/TCP` on the host and in the container: For web access, over HTTPS served by the dashboard itself. The dashboard runs as a non-root user and binds `443` because Docker Engine 20.10 and later set `net.ipv4.ip_unprivileged_port_start=0` in the network namespace of each container. This does not apply with `network_mode: host`.

Port mappings in `docker-compose.yml` will expose these container ports on the host. Adjust host ports if defaults cause conflicts.

In the `single-node` deployment the manager publishes these ports directly. In
the `multi-node` deployment the agent ports are published by the `nginx`
service, which balances `1517` (and the legacy `1514`) across the master and
worker nodes; enrollment travels over `1517` together with the agent traffic,
so it is balanced the same way. `wazuh.master` publishes the other manager
ports itself: `1515` and the Wazuh API on `55000`.

## Important Considerations

* **Production Environments**: For production, it's highly recommended to follow best practices for securing Docker and your host system. Consider using a multi-node setup for resilience.
* **Resource Allocation**: Monitor resource usage after deployment and adjust allocations (CPU, RAM for Docker, JVM heap for Wazuh Indexer) as necessary.

Meeting these requirements will pave the way for a smoother deployment and a more stable Wazuh-Docker experience.
