# Security

This section summarizes security recommendations for Wazuh Docker deployments (single-node and multi-node). Apply the controls that match your environment and risk profile.

## Credentials and secrets

- **No default passwords.** The images ship none. `tools/utils/deployment/credentials-conf.sh` generates random passwords for each deployment before its first start, and each component stores them on that start. Change them later with `password-tool.sh`. [Credentials](credentials.md) has the procedure.
- `tools/tests/check-default-credentials.sh` asserts that no account authenticates with its own username as its password.
- The OpenSearch demo accounts (`kibanaro`, `logstash`, `readall`, `snapshotrestore`, `anomalyadmin`) are removed from the Wazuh indexer image when it is built. They have no role in a Wazuh deployment and two of them were among the most privileged accounts present.
- `config/credentials/*.env` holds the deployment's passwords in clear text. The directory is in `.gitignore`: keep it out of your commits and restrict read access to the deployment directory.
- The containers receive those files as Compose secrets, not as environment variables, so `docker inspect` does not show the passwords, and the containers remove the keys from their environment once the values are stored. The Wazuh indexer and the Wazuh manager master publish the passwords they own in `export/credentials.env` of their configuration directory, readable by root only; the Wazuh dashboard has no `export/`, and a worker publishes only `ca.pem` (see [Credentials](credentials.md)). Passing the keys in the environment instead exposes them to anyone who can run `docker inspect`.
- Prefer injecting secrets at runtime (for example, via your CI/CD secret store or an external secrets manager) instead of keeping the files on the host.
- Rotate credentials regularly and after any suspected exposure.
- The Wazuh dashboard keeps its secrets in `opensearch_dashboards.keystore`, persisted in the `wazuh-dashboard-config` volume. It stores the Wazuh indexer credentials, the `wazuh-internal-client` password (`wazuh_core.hosts.default.password`) and the `wazuh_ai_assistant.encryptionKey`, generated at random on the first start and unique per deployment. Restrict access to that volume and to `docker compose exec` on the dashboard container, and do not copy the keystore between deployments.

### Manager cluster key

`<cluster><key>` authenticates the communication between manager nodes on port `1516`, and it is the only credential in that exchange. The manager image ships an empty key, so nothing usable for it is published inside the image:

- **A single manager** generates its own key on its first start, so no two deployments of the same image tag share a cluster secret.
- **The manager nodes of one cluster** need the same value. The multi-node Compose file gives both managers the `wazuh-cluster-key` volume on `/wazuh-cluster-key`: the first node to start creates a random key there and the others read it, so the cluster comes up on a secret that is unique to the deployment and is stored neither in the image nor in the repository. Nodes starting at the same time cannot disagree on it, and the value never appears in the container environment, so `docker inspect` and `/proc/<pid>/environ` do not expose it.
- **Manager nodes on separate hosts** cannot share that volume. Set `WAZUH_CLUSTER_KEY` to the same value on every node instead (`openssl rand -hex 16` generates one); it takes precedence over both the shared volume and the node's own configuration.

The key in use is written to `etc/wazuh-manager.conf` in each manager `etc` volume, so it is stable across restarts and container recreation.

- Treat the `wazuh-cluster-key` volume as a secret of the deployment: restrict access to it as you do for the certificates, and do not copy it, or the manager `etc` volumes, between deployments.
- To rotate the key of a multi-node deployment, remove the shared volume and start again. The first node to come up creates a new one and the rest of the nodes adopt it:
  ```bash
  docker compose down
  docker volume rm multi-node_wazuh-cluster-key
  docker compose up -d
  ```
- A manager `etc` volume keeps whatever key is stored in it. The multi-node configuration of the 4.x releases up to 4.14.8 carried one fixed key for every deployment: a manager `etc` volume carried over from one of them keeps that key until you set `WAZUH_CLUSTER_KEY`.

## Certificates and TLS

- Protect the generated `wazuh-certificates/` directory. Limit filesystem permissions and do not publish it.
- Regenerate certificates if private keys are leaked or if nodes are re-provisioned.
- Use certificates and TLS settings appropriate for production (trusted CA, correct DNS names, and key protection).

### Manager agent listener certificate

The Wazuh manager presents `/etc/wazuh-manager/certs/remoted.pem` and `/etc/wazuh-manager/certs/remoted-key.pem` on port `1517`, to both the agent listener and agent enrollment. **The manager does not create them, and it does not start without them.** They are issued by `wazuh-certs-tool.sh`, as `<node>-remoted.pem` and `<node>-remoted-key.pem`, and the Compose files mount them from the host. This is what makes the manager verifiable: agents anywhere trust one CA, the deployment's root CA, which covers every cluster node and survives recreating a manager container. Its certificate is copied to `config/root-ca/certs/root-ca.pem`; its private key stays in the CA directory of the host that issued the certificates.

The certificate is issued for that listener and nothing else: `CA:FALSE`, `keyUsage` limited to `digitalSignature` and `keyEncipherment`, `extendedKeyUsage` `serverAuth`, and a Subject Alternative Name holding the addresses agents dial. The file is the leaf followed by `root-ca.pem`, which is the chain agents receive in the handshake.

- It is a different pair from `<node>.pem`, which the manager presents to the Wazuh indexer as a client. Do not reuse one for the other: the key that faces agents would then also be the key that authenticates the indexer connection.
- The private key belongs on the deployment host only. Protect `wazuh-certificates/` and `config/*/certs`, and do not publish them or copy them between deployments.
- Distribute the root CA certificate, never the root CA key. `wazuh-certs-tool.sh` keeps the CA in `wazuh-ca/` next to the tool (or in the directory set in `WAZUH_CA_DIR`, which must be an absolute path), root-only, and never copies `root-ca.key` into `wazuh-certificates/`. Back that directory up: it is what issues certificates for new nodes. Run the tool from the same directory, or set the same `WAZUH_CA_DIR`, when you add nodes; otherwise it creates a new CA that the existing nodes do not trust.
- The addresses in the SAN are what agents can verify by name. Which ones belong there is part of the deployment steps — [single-node](getting-started/deployment/single-node.md), [multi-node](getting-started/deployment/multi-node.md).
- To rotate the pair, issue the certificates again, with the same `--agent-san` options as when the deployment was created, and restart:
  ```bash
  docker compose down
  sudo rm -rf wazuh-certificates/ config/*/certs
  sudo bash ../tools/utils/deployment/certificates-conf.sh --cert --copy --priv
  docker compose up -d
  ```
  The new certificates are signed by the same root CA, read from the CA directory, so enrolled agents keep working. A new root CA is only created when that directory holds none, and then every agent has to be given the new `config/root-ca/certs/root-ca.pem`.
- The files must be readable by the `wazuh-manager` group: `certificates-conf.sh --priv` leaves them `0:wazuh-manager` with mode `0640`, which is what the manager needs after it drops privileges.

### Manager Server API certificate

The Server API presents `/etc/wazuh-manager/certs/apid.pem` and `/etc/wazuh-manager/certs/apid-key.pem` on port `55000`. **The API does not create them, and the manager does not start without them** on the single-node manager and on every multi-node manager node, workers included: the manager's credential resolver checks the pair before the daemons start. They are issued by `wazuh-certs-tool.sh`, as `<node>-apid.pem` and `<node>-apid-key.pem`, with the same profile as the agent listener pair and signed by the same root CA, and the Compose files mount them from the host.

- The SAN holds the manager node's `ip` and `dns` entries from `config.yml`, `localhost`, `127.0.0.1` and `::1`, plus the addresses given with `--api-san`. The node's `dns` entry is the name the Wazuh dashboard uses (`WAZUH_API_URL`). Add with `--api-san` any other name or address API clients dial, for example the Docker host when `55000` is reached from outside. `--agent-san` addresses do not reach this certificate.
- Clients verify the API against `config/root-ca/certs/root-ca.pem`.
- It is rotated together with the other certificates, as described above.

### Dashboard verification of the indexer

The dashboard verifies the indexer with `opensearch.ssl.verificationMode: full`: the certificate must chain to `indexer-ca.pem`, which the Compose files mount from `config/root-ca/certs/root-ca.pem`, and must name the host the dashboard dialed. Every host in `OPENSEARCH_HOSTS` has to be a `dns` or `ip` entry of that indexer node in `config.yml`. The shipped Compose files meet this: `wazuh.indexer` on single-node, `wazuh1.indexer` to `wazuh3.indexer` on multi-node.

- When the dashboard reaches the indexer through another name or address, such as an external indexer, a load balancer or an IP address, add it to the indexer node in `config.yml` and issue the indexer certificate again. Until then the dashboard cannot query the indexer and logs `Hostname/IP does not match certificate's altnames`.
- `OPENSEARCH_SSL_VERIFICATION_MODE=certificate` checks the chain only. Every component of the deployment holds a certificate signed by the same root CA, so with that setting any of them is accepted as the indexer. Use it only as a temporary measure while the certificate is issued again.

### Agent verification of the manager

With nothing configured, an agent enrolled without a token does not verify the manager's certificate (`verification_mode` `none`) and logs `TLS verification is DISABLED`. To verify a manager presenting a certificate signed by this deployment's root CA, the agent needs that CA — `config/root-ca/certs/root-ca.pem` — through `WAZUH_MANAGER_CA` or dropped at `/var/ossec/etc/certs/manager-ca.pem`, deliberately not `root-ca.pem`, which is reserved for the trust anchor a token enrollment writes. An agent enrolled with `WAZUH_ENROLLMENT_TOKEN` needs none of this: the token supplies its own trust anchor. See [Environment Variables](configuration/environment-variables.md#wazuh-agent).

- Distribute the root CA certificate, never the root CA key.
- Do not leave verification off — unset, or `WAZUH_AGENT_SSL_VERIFICATION=none` — because a CA has not been distributed. The agent then accepts any certificate, from any peer, on a connection carrying enrollment credentials.
- Requiring agents to present a certificate of their own (mTLS) is a separate setting, `<remote><https><ca>` on the manager, off in the shipped configuration. Agents supply theirs with `WAZUH_AGENT_SSL_CERT` and `WAZUH_AGENT_SSL_KEY`.

## Network exposure

- Restrict access to exposed service ports at the host firewall and security group level.
- **The Wazuh indexer port (`9200`) is not published.** The manager and the dashboard reach the indexer over the Compose network, and the account that answers on that port administers the datastore, so publishing it puts an administrator-reachable endpoint on every interface of the host. If you need it for development, add the mapping bound to the loopback address (`127.0.0.1:9200:9200`) rather than to all interfaces.
- Do not expose internal-only endpoints to untrusted networks. In particular, limit access to the Wazuh API port (`55000`) to administrative networks.

## Host and runtime hardening

- Run Docker on a hardened host (patched OS, minimal installed packages, restricted SSH access).
- Limit access to the Docker daemon. Docker socket access grants administrative control over the host.
- Ensure persistent volumes and bind-mounted configuration files are backed by secure storage and appropriate permissions.
