#! /bin/sh

mdbook build